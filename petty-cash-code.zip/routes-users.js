const express = require('express');
const bcrypt = require('bcrypt');
const { pool } = require('./db');
const router = express.Router();

router.post('/', async (req, res) => {
  try {
    const { userId, role } = req.session;
    const { username, password, fullName, projectIds } = req.body;
    if (!username || !password || !fullName) return res.status(400).json({ error: 'Champs requis manquants' });

    let newRole;
    if (role === 'admin') newRole = 'client';
    else if (role === 'client') newRole = 'collaborator';
    else return res.status(403).json({ error: 'Accès refusé' });

    const hash = await bcrypt.hash(password, 10);
    const result = await pool.query(
      `INSERT INTO users (username, password_hash, full_name, role, created_by)
       VALUES ($1,$2,$3,$4,$5) RETURNING id, username, full_name, role`,
      [username, hash, fullName, newRole, userId]
    );
    const newUser = result.rows[0];

    if (newRole === 'collaborator' && Array.isArray(projectIds)) {
      for (const pid of projectIds) {
        await pool.query(
          `INSERT INTO project_access (project_id, user_id, granted_by) VALUES ($1,$2,$3)
           ON CONFLICT DO NOTHING`,
          [pid, newUser.id, userId]
        );
      }
    }
    res.json(newUser);
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'Cet identifiant existe déjà' });
    console.error(err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

router.get('/', async (req, res) => {
  try {
    const { userId } = req.session;
    const result = await pool.query(
      `SELECT u.id, u.username, u.full_name, u.role, u.active, u.created_at,
              COALESCE(
                json_agg(p.name) FILTER (WHERE p.name IS NOT NULL), '[]'
              ) AS project_names
       FROM users u
       LEFT JOIN project_access pa ON pa.user_id = u.id
       LEFT JOIN projects p ON p.id = pa.project_id
       WHERE u.created_by = $1
       GROUP BY u.id
       ORDER BY u.created_at DESC`,
      [userId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});


// Voir les projets actuellement accessibles a un utilisateur
router.get('/:id/access', async (req, res) => {
  try {
    const { userId, role } = req.session;
    const target = await pool.query('SELECT * FROM users WHERE id=$1', [req.params.id]);
    if (!target.rows[0]) return res.status(404).json({ error: 'Utilisateur introuvable' });
    if (role !== 'admin' && target.rows[0].created_by !== userId) return res.status(403).json({ error: 'Acces refuse' });
    const result = await pool.query('SELECT project_id FROM project_access WHERE user_id=$1', [req.params.id]);
    res.json(result.rows.map(r => r.project_id));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// Modifier le statut actif/inactif et/ou les projets accessibles
router.patch('/:id', async (req, res) => {
  try {
    const { userId, role } = req.session;
    const target = await pool.query('SELECT * FROM users WHERE id=$1', [req.params.id]);
    if (!target.rows[0]) return res.status(404).json({ error: 'Utilisateur introuvable' });
    if (role !== 'admin' && target.rows[0].created_by !== userId) return res.status(403).json({ error: 'Acces refuse' });

    const { active, projectIds } = req.body;

    if (typeof active === 'boolean') {
      await pool.query('UPDATE users SET active=$1 WHERE id=$2', [active, req.params.id]);
    }

    if (Array.isArray(projectIds)) {
      await pool.query('DELETE FROM project_access WHERE user_id=$1', [req.params.id]);
      for (const pid of projectIds) {
        await pool.query(
          'INSERT INTO project_access (project_id, user_id, granted_by) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING',
          [pid, req.params.id, userId]
        );
      }
    }

    const updated = await pool.query('SELECT id, username, full_name, role, active FROM users WHERE id=$1', [req.params.id]);
    res.json(updated.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});


// Supprimer definitivement un utilisateur
router.delete('/:id', async (req, res) => {
  try {
    const { userId, role } = req.session;
    const target = await pool.query('SELECT * FROM users WHERE id=$1', [req.params.id]);
    if (!target.rows[0]) return res.status(404).json({ error: 'Utilisateur introuvable' });
    if (role !== 'admin' && target.rows[0].created_by !== userId) return res.status(403).json({ error: 'Acces refuse' });

    await pool.query('DELETE FROM project_access WHERE user_id=$1', [req.params.id]);
    await pool.query('DELETE FROM users WHERE id=$1', [req.params.id]);
    res.json({ ok: true });
  } catch (err) {
    if (err.code === '23503') {
      return res.status(409).json({ error: 'Impossible: cet utilisateur a deja enregistre des bons/tickets. Desactivez-le plutot pour garder l\'historique.' });
    }
    console.error(err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

module.exports = router;
