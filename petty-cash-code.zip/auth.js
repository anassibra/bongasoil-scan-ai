(function () {
  const authScreen = document.getElementById('authScreen');
  const projectsScreen = document.getElementById('projectsScreen');
  const appScreen = document.getElementById('appScreen');

  function showOnly(el) {
    [authScreen, projectsScreen, appScreen].forEach(s => { if (s) s.style.display = 'none'; });
    if (el) el.style.display = el === appScreen ? 'block' : 'flex';
  }

  function openModal(id) { document.getElementById(id).classList.add('is-open'); }
  function closeModal(id) { document.getElementById(id).classList.remove('is-open'); }

  async function checkSession() {
    try {
      const res = await fetch('/api/me');
      if (res.ok) {
        window.currentUser = await res.json();
        loadProjects();
      } else {
        showOnly(authScreen);
      }
    } catch (e) {
      showOnly(authScreen);
    }
  }

  document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;
    const errorEl = document.getElementById('loginError');
    errorEl.style.display = 'none';
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      if (!res.ok) {
        errorEl.textContent = data.error || 'Erreur de connexion';
        errorEl.style.display = 'block';
        return;
      }
      window.currentUser = data;
      loadProjects();
    } catch (err) {
      errorEl.textContent = 'Erreur reseau';
      errorEl.style.display = 'block';
    }
  });

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
  }

  async function loadProjects() {
    showOnly(projectsScreen);
    document.getElementById('btnManageUsers').style.display =
      (window.currentUser.role === 'collaborator') ? 'none' : 'inline-flex';

    const list = document.getElementById('projectsList');
    list.innerHTML = '<p class="projects-empty">Chargement...</p>';
    try {
      const res = await fetch('/api/projects');
      const projects = await res.json();
      if (!projects.length) {
        list.innerHTML = '<p class="projects-empty">Aucun projet pour le moment. Creez-en un.</p>';
        return;
      }
      list.innerHTML = '';
      projects.forEach(p => {
        const card = document.createElement('div');
        card.className = 'project-card';
        card.innerHTML = `<h3>${escapeHtml(p.name)}</h3>
          <p>${escapeHtml(p.production || '')}</p>
          <p class="project-responsable">${escapeHtml(p.responsable || '')}</p>`;
        card.addEventListener('click', () => openProject(p));
        list.appendChild(card);
      });
    } catch (e) {
      list.innerHTML = '<p class="projects-empty">Erreur de chargement.</p>';
    }
  }

  document.getElementById('newProjectForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('newProjectName').value.trim();
    const production = document.getElementById('newProjectProduction').value.trim();
    const responsable = document.getElementById('newProjectResponsable').value.trim();
    if (!name) return;
    const res = await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, production, responsable })
    });
    if (res.ok) {
      document.getElementById('newProjectForm').reset();
      closeModal('newProjectModal');
      loadProjects();
    } else {
      alert('Erreur lors de la creation du projet.');
    }
  });

  document.getElementById('btnShowNewProject').addEventListener('click', () => openModal('newProjectModal'));
  document.getElementById('btnCancelNewProject').addEventListener('click', () => closeModal('newProjectModal'));

  async function openProject(project) {
    window.currentProject = project;
    sessionStorage.setItem('currentProjectId', project.id);
    document.getElementById('currentProjectName').textContent = project.name;
    showOnly(appScreen);
    try {
      await loadRecords();
      await loadTollRecords();
      await loadChargeRecords();
      updateAllFilterDropdowns();
      renderStats();
      renderTable();
      updateTollFilterDropdowns();
      renderTollTable();
      updateChargeFilterDropdowns();
      renderChargeTable();
    } catch (e) {
      console.error('Erreur chargement du projet:', e);
    }
  }

  document.getElementById('btnBackToProjects').addEventListener('click', loadProjects);

  document.getElementById('btnLogout').addEventListener('click', async () => {
    await fetch('/api/logout', { method: 'POST' });
    window.currentUser = null;
    window.currentProject = null;
    sessionStorage.removeItem('currentProjectId');
    showOnly(authScreen);
  });

  async function loadUsers() {
    const list = document.getElementById('usersList');
    list.innerHTML = '<p class="projects-empty">Chargement...</p>';
    try {
      const res = await fetch('/api/users');
      const users = await res.json();
      if (!users.length) {
        list.innerHTML = '<p class="projects-empty">Aucun utilisateur cree pour le moment.</p>';
        return;
      }
      list.innerHTML = '';
      users.forEach(u => {
        const row = document.createElement('div');
        row.className = 'user-row user-row-manage';
        const statusLabel = u.active ? 'Actif' : 'Desactive';
        const statusClass = u.active ? 'status-active' : 'status-inactive';
        row.innerHTML = `<div class="user-row-top">
            <div>
              <strong>${escapeHtml(u.full_name)}</strong>
              <span class="user-role-badge">${u.role === 'client' ? 'Client' : 'Collaborateur'}</span>
              <span class="user-status-badge ${statusClass}">${statusLabel}</span>
              <div class="user-username">@${escapeHtml(u.username)}</div>
              ${u.role === 'collaborator' ? '<div class="user-projects">' + (u.project_names && u.project_names.length ? '📁 ' + u.project_names.map(escapeHtml).join(', ') : '<span class=\'no-access\'>Aucun projet assigne</span>') + '</div>' : ''}
            </div>
          </div>
          <div class="user-row-actions">
            ${u.role === 'collaborator' ? '<button type="button" class="btn-link btn-edit-access" data-id="' + u.id + '">Modifier acces</button>' : ''}
            <button type="button" class="btn-link btn-toggle-active" data-id="${u.id}" data-active="${u.active}">${u.active ? 'Desactiver' : 'Reactiver'}</button>
            <button type="button" class="btn-link btn-delete-user" data-id="${u.id}" style="color:#dc2626;">Supprimer</button>
          </div>
          <div id="editAccessBox-${u.id}" class="edit-access-box" style="display:none;"></div>`;
        list.appendChild(row);
      });

      list.querySelectorAll('.btn-toggle-active').forEach(btn => {
        btn.addEventListener('click', async () => {
          const id = btn.dataset.id;
          const currentlyActive = btn.dataset.active === 'true';
          if (!confirm(currentlyActive ? 'Desactiver ce compte ?' : 'Reactiver ce compte ?')) return;
          const res = await fetch('/api/users/' + id, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ active: !currentlyActive })
          });
          if (res.ok) loadUsers(); else alert('Erreur lors de la mise a jour.');
        });
      });

      list.querySelectorAll('.btn-delete-user').forEach(btn => {
        btn.addEventListener('click', async () => {
          const id = btn.dataset.id;
          if (!confirm('Supprimer definitivement ce compte ? Cette action est irreversible.')) return;
          const res = await fetch('/api/users/' + id, { method: 'DELETE' });
          const data = await res.json();
          if (res.ok) { loadUsers(); } else { alert(data.error || 'Erreur lors de la suppression.'); }
        });
      });

      list.querySelectorAll('.btn-edit-access').forEach(btn => {
        btn.addEventListener('click', async () => {
          const id = btn.dataset.id;
          const box = document.getElementById('editAccessBox-' + id);
          if (box.style.display === 'block') { box.style.display = 'none'; return; }
          box.style.display = 'block';
          box.innerHTML = 'Chargement...';
          try {
            const [projectsRes, accessRes] = await Promise.all([
              fetch('/api/projects'),
              fetch('/api/users/' + id + '/access')
            ]);
            const projects = await projectsRes.json();
            const currentAccess = await accessRes.json();
            box.innerHTML = '';
            const list2 = document.createElement('div');
            list2.className = 'project-checkbox-box';
            projects.forEach(p => {
              const label = document.createElement('label');
              label.className = 'project-checkbox-row';
              const checked = currentAccess.includes(p.id) ? 'checked' : '';
              label.innerHTML = '<input type="checkbox" value="' + p.id + '" ' + checked + '> ' + escapeHtml(p.name);
              list2.appendChild(label);
            });
            box.appendChild(list2);
            const saveBtn = document.createElement('button');
            saveBtn.type = 'button';
            saveBtn.className = 'btn-primary';
            saveBtn.style.marginTop = '8px';
            saveBtn.textContent = 'Enregistrer les acces';
            saveBtn.addEventListener('click', async () => {
              const projectIds = Array.from(list2.querySelectorAll('input:checked')).map(cb => parseInt(cb.value));
              const res = await fetch('/api/users/' + id, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ projectIds })
              });
              if (res.ok) { box.style.display = 'none'; } else { alert('Erreur.'); }
            });
            box.appendChild(saveBtn);
          } catch (e) {
            box.innerHTML = 'Erreur de chargement.';
          }
        });
      });
    } catch (e) {
      list.innerHTML = '<p class="projects-empty">Erreur de chargement.</p>';
    }
  }

  document.getElementById('btnManageUsers').addEventListener('click', () => {
    openModal('usersModal');
    loadUsers();
    setupProjectCheckboxes();
  });

  async function setupProjectCheckboxes() {
    const wrap = document.getElementById('newUserProjectsWrap');
    if (window.currentUser.role !== 'client') {
      wrap.style.display = 'none';
      return;
    }
    wrap.style.display = 'block';
    const box = document.getElementById('newUserProjectsList');
    box.innerHTML = 'Chargement...';
    try {
      const res = await fetch('/api/projects');
      const projects = await res.json();
      if (!projects.length) {
        box.innerHTML = '<p class="projects-empty" style="padding:8px 0;">Creez d\'abord un projet.</p>';
        return;
      }
      box.innerHTML = '';
      projects.forEach(p => {
        const label = document.createElement('label');
        label.className = 'project-checkbox-row';
        label.innerHTML = '<input type="checkbox" value="' + p.id + '"> ' + escapeHtml(p.name);
        box.appendChild(label);
      });
    } catch (e) {
      box.innerHTML = '<p class="projects-empty">Erreur de chargement.</p>';
    }
  }
  document.getElementById('btnCloseUsersModal').addEventListener('click', () => closeModal('usersModal'));

  document.getElementById('newUserForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('newUserUsername').value.trim();
    const password = document.getElementById('newUserPassword').value;
    const fullName = document.getElementById('newUserFullName').value.trim();
    const errorEl = document.getElementById('newUserError');
    errorEl.style.display = 'none';
    if (!username || !password || !fullName) return;
    try {
      const res = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username, password, fullName,
          projectIds: Array.from(document.querySelectorAll('#newUserProjectsList input:checked')).map(cb => parseInt(cb.value))
        })
      });
      const data = await res.json();
      if (!res.ok) {
        errorEl.textContent = data.error || 'Erreur lors de la creation.';
        errorEl.style.display = 'block';
        return;
      }
      document.getElementById('newUserForm').reset();
      loadUsers();
    } catch (err) {
      errorEl.textContent = 'Erreur reseau.';
      errorEl.style.display = 'block';
    }
  });

  checkSession();
})();

// Bascule affichage/masquage des mots de passe
document.querySelectorAll('.btn-eye').forEach(btn => {
  btn.addEventListener('click', () => {
    const input = document.getElementById(btn.dataset.target);
    if (input.type === 'password') {
      input.type = 'text';
      btn.textContent = '🙈';
    } else {
      input.type = 'password';
      btn.textContent = '👁';
    }
  });
});
